<?php
/**
 * Plugin Name: TeakAcacia Shipping GraphQL
 * Description: Exposes WooCommerce shipping settings to GraphQL for frontend display
 * Version: 1.0.0
 * Author: TeakAcacia
 * Requires at least: 5.0
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Only run if WPGraphQL and WooCommerce are active
add_action('plugins_loaded', function() {
    if (!class_exists('WPGraphQL') || !class_exists('WooCommerce')) {
        return;
    }

    // Register shipping zones query
    add_action('graphql_register_types', function() {
        
        // Register ShippingMethod type
        register_graphql_object_type('ShippingMethod', [
            'description' => 'A shipping method',
            'fields' => [
                'id' => ['type' => 'String'],
                'title' => ['type' => 'String'],
                'methodId' => ['type' => 'String'],
                'type' => ['type' => 'String'],
                'cost' => ['type' => 'String'],
                'minAmount' => ['type' => 'String'],
                'enabled' => ['type' => 'Boolean'],
            ],
        ]);

        // Register ShippingZone type
        register_graphql_object_type('ShippingZoneType', [
            'description' => 'A shipping zone',
            'fields' => [
                'id' => ['type' => 'Int'],
                'name' => ['type' => 'String'],
                'methods' => [
                    'type' => ['list_of' => 'ShippingMethod'],
                    'description' => 'Shipping methods for this zone',
                ],
            ],
        ]);

        // Register query to get all shipping zones
        register_graphql_field('RootQuery', 'shippingSettings', [
            'type' => ['list_of' => 'ShippingZoneType'],
            'description' => 'Get all WooCommerce shipping zones and methods',
            'resolve' => function() {
                if (!class_exists('WC_Shipping_Zones')) {
                    return [];
                }

                $zones = WC_Shipping_Zones::get_zones();
                $result = [];

                foreach ($zones as $zone_data) {
                    $zone_id = $zone_data['id'];
                    $zone = new WC_Shipping_Zone($zone_id);
                    $shipping_methods = $zone->get_shipping_methods(true); // Get enabled methods
                    
                    $methods = [];
                    foreach ($shipping_methods as $method) {
                        if ($method->enabled !== 'yes') {
                            continue;
                        }

                        $method_data = [
                            'id' => $method->get_instance_id(),
                            'title' => $method->get_title(),
                            'methodId' => $method->id,
                            'enabled' => true,
                        ];

                        // Get type and specific settings
                        if ($method->id === 'free_shipping') {
                            $method_data['type'] = 'free';
                            $min_amount = $method->get_option('min_amount');
                            if ($min_amount) {
                                $method_data['minAmount'] = $min_amount;
                            }
                        } elseif ($method->id === 'flat_rate') {
                            $method_data['type'] = 'flat_rate';
                            $cost = $method->get_option('cost');
                            if ($cost) {
                                $method_data['cost'] = $cost;
                            }
                        } elseif ($method->id === 'local_pickup') {
                            $method_data['type'] = 'local_pickup';
                            $cost = $method->get_option('cost');
                            if ($cost) {
                                $method_data['cost'] = $cost;
                            }
                        } else {
                            $method_data['type'] = 'other';
                        }

                        $methods[] = $method_data;
                    }

                    $result[] = [
                        'id' => $zone_id,
                        'name' => $zone_data['zone_name'],
                        'methods' => $methods,
                    ];
                }

                return $result;
            },
        ]);
    });
});
